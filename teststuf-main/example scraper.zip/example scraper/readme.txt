# create virtual env
python3 -m venv .venv

# activate virtual environment
source ./.venv/bin/activate	# on mac
./.venv/bin/activate		# on windows

# install python package listed in requirements.txt
pip install -r requirements.txt

utils.ipynb is a tutorial on the library that I use. 
You can don't use it and build your own, but is more convenient to use it.

example of process.png is an illustration on how each scraper's process might look like
the process in between doesn't matter only the resulting end file matter.